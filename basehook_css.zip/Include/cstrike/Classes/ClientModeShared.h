#pragma once

class ClientModeShared;

extern ClientModeShared* clientmode;