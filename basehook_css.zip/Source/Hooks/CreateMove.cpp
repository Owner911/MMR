#include "Hooks.h"

std::unique_ptr<VMTHook> clientmode_hook;

bool __fastcall Hooks::CreateMove(ClientModeShared* thisptr, void* edx, float frametime, CUserCmd* command) {
	// Don't do anything when called from CInput::ExtraMouseSample.
	if (!command->command_number)
		return false;

	return false;
}